AF-MilitaryShogi（軍人将棋） Windows版

■ 動作環境
Windows 10 / 11（64bit）。別途インストールするランタイムや外部ツールはありません。

■ 起動
ZIPをすべて展開し、フォルダー内の AF-MilitaryShogi.exe を起動してください。
（EXEだけを別の場所へコピーすると起動できません）

■ あそびかた
画面上部の「あそびかた」に、勝敗の条件・全16種の駒・戦闘相性・動き方があります。
・自軍の駒をクリック → 移動先（緑）または攻撃先（赤）をクリック
・F2：対戦モード ⇔ 研究モード（CPUの思考モニター等）
・敵駒にマウスを合わせると、公開された観測情報（移動・戦闘の記録）を表示

■ 保存されるデータ
配置プリセットと設定：%USERPROFILE%\AppData\LocalLow\AF\AF-MilitaryShogi\

■ 素材について
駒の文字は昭和書体「闘龍」（KSO闘龍）で描画した画像です（フォントファイルは同梱していません）。
使用許諾：https://designpocket.jp/font/detail/23984
効果音は外部素材を使わず、プログラムで生成しています。

■ ライセンス
ソースコード：MIT License（Copyright (c) 2026 af）
素材：作者が作成したものはCC BY 4.0。製品名・ロゴ・アイコンと、KSO闘龍で描いた駒の文字の画像は許諾対象外です。
詳細：https://github.com/naoki927higuchi/AF-MilitaryShogi/blob/master/LICENSE-ASSETS.md
Unityのランタイムなど第三者のものは、それぞれのライセンスに従います。
